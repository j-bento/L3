package couvertureEtMutation;

public class TableauVideException extends Exception {

}
