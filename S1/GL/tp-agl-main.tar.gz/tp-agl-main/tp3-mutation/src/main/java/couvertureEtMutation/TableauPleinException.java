package couvertureEtMutation;

public class TableauPleinException extends Exception {

}
