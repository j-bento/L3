package agl.tp2_Poste;

public class ColisExpressInvalide extends Exception {

	private static final long serialVersionUID = -7135718158735538L;

	public ColisExpressInvalide(String string) {
		super(string);
	}

}