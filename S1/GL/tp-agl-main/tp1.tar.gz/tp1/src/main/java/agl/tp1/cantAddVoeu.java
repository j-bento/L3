package agl.tp1;

public class cantAddVoeu extends Exception {

	public cantAddVoeu(String string) {
		super(string);
	}

}
