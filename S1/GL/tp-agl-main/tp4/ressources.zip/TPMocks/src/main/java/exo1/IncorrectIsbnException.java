package exo1;

public class IncorrectIsbnException extends Exception {

}
