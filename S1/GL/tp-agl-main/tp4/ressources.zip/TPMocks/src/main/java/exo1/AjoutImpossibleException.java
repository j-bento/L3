package exo1;

public class AjoutImpossibleException extends Exception {

}
