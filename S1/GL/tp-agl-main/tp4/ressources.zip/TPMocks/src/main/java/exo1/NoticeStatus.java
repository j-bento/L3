package exo1;

public enum NoticeStatus {
	newlyAdded, updated, nochange, notExisting;
}
